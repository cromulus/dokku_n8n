import {
	IAuthenticateGeneric,
	ICredentialDataDecryptedObject,
	ICredentialTestRequest,
	ICredentialType,
	INodeProperties,
} from 'n8n-workflow';

export class RemindersApi implements ICredentialType {
	name = 'remindersApi';
	displayName = 'Reminders API';
	documentationUrl = 'https://github.com/your-username/n8n-nodes-reminders-api';
	properties: INodeProperties[] = [
		{
			displayName: 'API Base URL',
			name: 'baseUrl',
			type: 'string',
			default: 'http://localhost:8080',
			description: 'The base URL of your Reminders API server',
			required: true,
			placeholder: 'http://localhost:8080',
		},
		{
			displayName: 'API Token',
			name: 'apiToken',
			type: 'string',
			typeOptions: { password: true },
			default: '',
			description: 'Your Reminders API authentication token',
		},
		{
			displayName: 'Authentication Required',
			name: 'authRequired',
			type: 'boolean',
			default: false,
			description: 'Whether authentication is required for all API calls',
		},
	];

	authenticate: IAuthenticateGeneric = {
		type: 'generic',
		properties: {
			headers: {
				Authorization: '=Bearer {{$credentials.apiToken}}',
			},
		},
	};

	test: ICredentialTestRequest = {
		request: {
			baseURL: '={{$credentials.baseUrl}}',
			url: '/lists',
			method: 'GET',
		},
	};

	validate(credentials: ICredentialDataDecryptedObject): ICredentialTestRequest | null {
		const { baseUrl } = credentials as { baseUrl: string };
		
		// Basic URL validation
		if (!baseUrl) {
			throw new Error('API Base URL is required. Please enter the base URL of your Reminders API server (e.g., http://localhost:8080)');
		}
		
		try {
			const url = new URL(baseUrl);
			// Ensure it's a valid HTTP/HTTPS URL
			if (!['http:', 'https:'].includes(url.protocol)) {
				throw new Error('API Base URL must use HTTP or HTTPS protocol');
			}
		} catch (error) {
			throw new Error(`Invalid API Base URL format: ${baseUrl}. Please enter a valid URL (e.g., http://localhost:8080)`);
		}
		
		return this.test;
	}
}
